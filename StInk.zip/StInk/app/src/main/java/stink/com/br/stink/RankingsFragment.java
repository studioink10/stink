package stink.com.br.stink;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class RankingsFragment extends Fragment {

    String [] tatuadores = new String[]{
            "Eduardo Souza",
            "Lucas Farias",
            "Caio Luka",
    };

    int [] imagensTatuadores = new int[]{
            R.drawable.ic_baseline_person_outline_24px,
            R.drawable.ic_baseline_person_outline_24px,
            R.drawable.ic_baseline_person_outline_24px,
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Each row in the list stores country name, currency and flag
        List<HashMap<String, String>> aList = new ArrayList<HashMap<String, String>>();

        for (int i = 0; i < 10; i++) {
            HashMap<String, String> hm = new HashMap<String, String>();
            hm.put("txt", "Tatuadores : " + tatuadores[i]);
            hm.put("img", Integer.toString(imagensTatuadores[i]));
            aList.add(hm);
        }

        // Keys used in Hashmap
        String[] from = { "img","txt"};

        // Ids of views in listview_layout
       // int[] to = { R.id.img,R.id.txt};

        // Instantiating an adapter to store each items
        // R.layout.listview_layout defines the layout of each item
       // SimpleAdapter adapter = new SimpleAdapter(getActivity().getBaseContext(), aList, R.layout.fragment_rankings, from, to);

        // Getting a reference to listview of main.xml layout file
        ListView listView = ( ListView ) getActivity().findViewById(R.id.list_item);

        // Setting the adapter to the listView
       // listView.setAdapter(adapter);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_rankings, container, false);

    }
}