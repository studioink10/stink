package stink.com.br.stink;

import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView mTextMessage;
    //private Fragment selectedFragment;
    private PostsFragment postsFragment;
    private RankingsFragment rankingsFragment;
    private SocialFragment socialFragment;
    private BuscarActivity buscarActivity;
    private PerfilFragment perfilFragment;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            switch (item.getItemId()) {
                case R.id.navigation_social:
                    setFragment(socialFragment);
                    //selectedFragment = new SocialFragment();
                    //Intent intent =  new Intent(MainActivity.this, SocialActivity.class);
                    //startActivity(intent);
                    //break;
                //mTextMessage.setText(R.string.title_social);
                return true;
                case R.id.navigation_busca:
                    setFragment(buscarActivity);
                    return true;
                case R.id.navigation_tattoos:
                    mTextMessage.setText(R.string.title_tattoos);
                    return true;
                case R.id.navigation_chat:
                    mTextMessage.setText(R.string.title_em_breve);
                    return true;
                case R.id.navigation_perfil:
                    setFragment(perfilFragment);
                    return true;
            }
            return false;
        }
    };

    private void setFragment(Fragment fragment) {
        android.support.v4.app.FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container,fragment);
        fragmentTransaction.commit();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buscarActivity = new BuscarActivity();
        perfilFragment = new PerfilFragment();
        postsFragment = new PostsFragment();
        rankingsFragment = new RankingsFragment();
        socialFragment = new SocialFragment();


        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new SocialFragment()).commit();
    }
}
